const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const fmt = n => n.toLocaleString("en-GB");
const ds = id => DATASETS.find(d => d.id === id);
const uni = id => UNIVERSITIES.find(u => u.id === id);
const TOTAL = DATASETS.reduce((s, d) => s + d.count, 0);
const pct = (n, of) => { const p = 100 * n / of; return p < 1 ? (p < 0.1 ? "<0.1" : p.toFixed(1)) : Math.round(p); };

const ICON = {
  info: '<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></svg>',
  search: '<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
  ext: '<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>',
  filter: '<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h16M7 12h10M10 18h4"/></svg>',
  close: '<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>',
  spark: '<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M6 18l2.5-2.5M15.5 8.5 18 6"/></svg>'
};

const state = {
  universities: { q: "", country: new Set(), inception: [1218, 1966], students: [17345, 40000] },
  units: { q: "", uni: new Set(), type: new Set(), topic: new Set() },
  expanded: new Set(), hints: new Set()
};

/* Routing: plain hash names only (home, units, units-info, unit-<id>, university-<id>, search). */
function route() {
  const h = decodeURIComponent(location.hash.slice(1)) || "home";
  const info = h.endsWith("-info");
  const base = info ? h.slice(0, -5) : h;
  document.body.classList.remove("drawer-open");
  let html;
  if (base === "home") html = home(info);
  else if (base === "universities") html = universities(info);
  else if (base === "units") html = units(info);
  else if (base.startsWith("university-") && uni(base.slice(11))) html = universityPage(uni(base.slice(11)), info);
  else if (base.startsWith("unit-") && UNITS.find(u => u.id === base.slice(5))) html = unitPage(UNITS.find(u => u.id === base.slice(5)), info);
  else if (base === "search") html = searchPage();
  else html = home(false);
  $("#app").innerHTML = html;
  const navKey = base.startsWith("universit") ? "universities" : base.startsWith("unit") ? "units" : base === "home" ? "home" : "";
  document.querySelectorAll(".bar nav a").forEach(a => a.toggleAttribute("aria-current", a.dataset.nav === navKey));
  document.title = (base === "home" ? "" : (ds(base)?.label || $("#app h1")?.textContent || "") + " | ") + "EC2U Knowledge Hub";
  if (!routing.keepScroll) window.scrollTo(0, 0);
  routing.keepScroll = false;
}
const routing = { keepScroll: false };
function go(hash, keepScroll) { routing.keepScroll = !!keepScroll; if (location.hash.slice(1) === hash) route(); else location.hash = hash; }

function helpToggle(base, info) {
  return `<a class="help" href="#${base}${info ? "" : "-info"}" aria-pressed="${info}" title="${info ? "Hide" : "Show"} information about this page">${ICON.info}<span>${info ? "Hide info" : "Info"}</span></a>`;
}

/* ---------- Home ---------- */
function home(info) {
  const tiles = DATASETS.map(d => `
    <li><a href="${d.live ? "#" + d.id : "#search"}" data-series="${d.series}" ${d.live ? "" : `data-scope="${d.id}"`}>
      <span class="name"><span class="mark"></span>${esc(d.label)}</span>
      <span class="count num">${fmt(d.count)}</span>
      <span class="share"><span class="track"><span style="width:${100 * d.count / TOTAL}%"></span></span>
        <span class="num">${pct(d.count, TOTAL)}% of all records</span></span>
    </a></li>`).join("");
  const opts = DATASETS.map(d => `<option value="${d.id}">${esc(d.label)}</option>`).join("");
  const unis = UNIVERSITIES.map(u => `
    <li><a href="#university-${u.id}"><img src="${IMG[u.id]}" alt="" loading="lazy"><strong>${esc(u.name)}</strong>
      <span class="label">${esc(u.city)}, ${esc(u.country)}</span></a></li>`).join("");
  return `
  <section class="hero">
    <div class="wrap">
      <div class="title-row" style="justify-content:flex-end">${helpToggle("home", info)}</div>
      ${info ? infoHome() : ""}
      <h1>Discover EC2U data</h1>
      <p class="lede">Open data on the courses, programmes, research, events and governance of the nine universities of the European Campus of City-Universities.</p>
      <form class="search" role="search" onsubmit="return submitSearch(event)">
        <div class="field">
          <label class="sr" for="scope">Search in</label>
          <select id="scope" name="scope"><option value="all">All data</option>${opts}</select>
          <label class="sr" for="q">Search terms</label>
          <input id="q" name="q" type="search" placeholder="Search by name, e.g. photonics, Salamanca, robotics" autocomplete="off">
        </div>
        <button look="strong" type="submit">${ICON.search}<span>Search</span></button>
      </form>
      <ul class="tiles" aria-label="Datasets">${tiles}</ul>
    </div>
  </section>
  <section class="section">
    <div class="wrap">
      <h2>Partner universities</h2>
      <p>Nine universities in nine countries, from the Iberian Peninsula to the Arctic Circle.</p>
      <ul class="unis">${unis}</ul>
    </div>
  </section>
  <section class="section" style="padding-top:0">
    <div class="wrap">
      <h2>About the data</h2>
      <p>Records are harvested from partner university sources and published as linked data, with a model and API generated from the same definitions.</p>
      <dl class="facts">
        <div><dt>Publisher</dt><dd><a href="https://ec2u.eu/">EC2U Alliance</a></dd></div>
        <div><dt>Licence</dt><dd><a href="https://creativecommons.org/licenses/by-nc-nd/4.0/">CC BY-NC-ND 4.0</a></dd></div>
        <div><dt>Data model and API</dt><dd><a href="#home-info">Catalogue information</a></dd></div>
        <div><dt>Source code</dt><dd><a href="https://github.com/ec2u/data">github.com/ec2u/data</a></dd></div>
      </dl>
    </div>
  </section>`;
}

function infoHome() {
  return `<aside class="info" aria-label="About this catalogue">
    <div class="info-grid">
      <div>
        <h2>EC2U Dataset Catalog</h2>
        <p>Datasets published on the EC2U Knowledge Hub.</p>
        <dl>
          <dt>Publisher</dt><dd>EC2U Alliance</dd>
          <dt>Licence</dt><dd>CC BY-NC-ND 4.0</dd>
          <dt>Datasets</dt><dd class="num">6</dd>
          <dt>Records</dt><dd class="num">${fmt(TOTAL)}</dd>
        </dl>
      </div>
      <div>
        <h2>Reference</h2>
        <ul class="links">
          <li><a href="#units-info">Data model</a></li><li><a href="#units-info">API specification</a></li>
          <li><a href="#units-info">Taxonomies</a></li><li><a href="https://github.com/ec2u/data">Source code</a></li>
        </ul>
        <p class="label" style="margin-top:var(--skin--spacing-075)">Each dataset’s Info view links to its own generated model and API.</p>
      </div>
    </div>
  </aside>`;
}

function submitSearch(e) {
  e.preventDefault();
  const scope = $("#scope").value, q = $("#q").value.trim();
  if (scope === "universities" || scope === "units") { state[scope].q = q; go(scope); }
  else { state.search = { scope, q }; go("search"); }
  return false;
}

/* ---------- Search (All) ---------- */
function searchPage() {
  const { scope = "all", q = "" } = state.search || {};
  const needle = q.toLowerCase();
  const uh = UNIVERSITIES.filter(u => !needle || (u.name + u.city + u.country).toLowerCase().includes(needle));
  const nh = UNITS.filter(u => !needle || (u.name + u.topics.join(" ") + u.type).toLowerCase().includes(needle));
  const other = scope !== "all" ? ds(scope) : null;
  const group = (d, items, row) => `
    <section style="margin-bottom:var(--skin--spacing-200)" data-series="${d.series}">
      <h2 style="display:flex;align-items:center;gap:.5em;font-size:1.1em"><span class="mark"></span>${esc(d.label)}
        <span class="label num" style="font-weight:400">${items.length}</span></h2>
      ${items.length ? `<ul class="results">${items.slice(0, 5).map(row).join("")}</ul>
        ${items.length > 5 ? `<a href="#${d.id}" onclick="state.${d.id}.q=${esc(JSON.stringify(q))}">All ${items.length} matches in ${esc(d.label)}</a>` : ""}`
        : `<p class="empty" style="padding:0">No matches.</p>`}
    </section>`;
  return `<div class="wrap">
    <div class="page-head"><div class="crumbs"><a href="#home">Home</a> ›</div>
      <div class="title-row"><h1>${q ? `Results for “${esc(q)}”` : "All records"}</h1></div></div>
    ${other ? `<p class="note">${esc(other.label)} isn’t part of this mockup yet. Showing matches in Universities and Units.</p>` : ""}
    <p class="note">Mockup: units are searched in a 40-record sample.</p>
    ${group(ds("universities"), uh, u => `<li><a class="r-title" href="#university-${u.id}">${esc(u.name)}</a><div class="r-meta"><span>${esc(u.city)}, ${esc(u.country)}</span></div></li>`)}
    ${group(ds("units"), nh, unitRow)}
  </div>`;
}

/* ---------- Shared listing parts ---------- */
function hintFor(dataset, key, label) {
  const open = state.hints.has(dataset + key);
  return `<div class="facet-head"><h2>${esc(label)}</h2>
    <button class="hint-btn" type="button" aria-expanded="${open}" aria-label="About ${esc(label)}" onclick="toggleHint('${dataset}','${key}')">${ICON.info}</button></div>
    ${open ? `<p class="hint">${esc(MODEL[dataset][key])} <a href="#${dataset}-info">Data model</a></p>` : ""}`;
}
function toggleHint(d, k) { const id = d + k; state.hints.has(id) ? state.hints.delete(id) : state.hints.add(id); rerender(); }

function checklist(dataset, key, entries, limit) {
  const set = state[dataset][key], max = Math.max(...entries.map(e => e[2])), flat = entries.every(e => e[2] === max);
  const expanded = state.expanded.has(dataset + key);
  const shown = expanded || !limit ? entries : entries.slice(0, limit);
  return `<ul class="opts">${shown.map(([v, label, n]) => `
    <li><label class="opt"><input type="checkbox" ${set.has(v) ? "checked" : ""} onchange="toggleOpt('${dataset}','${key}',${esc(JSON.stringify(v))})">
      <span class="t">${esc(label)}</span><span class="n num">${fmt(n)}</span>
      ${flat ? "" : `<span class="track"><span style="width:${100 * n / max}%"></span></span>`}</label></li>`).join("")}</ul>
    ${limit && entries.length > limit ? `<button class="more" type="button" onclick="toggleMore('${dataset}','${key}')">${expanded ? "Show fewer" : `Show all ${entries.length}`}</button>` : ""}`;
}
function toggleOpt(d, k, v) { const s = state[d][k]; s.has(v) ? s.delete(v) : s.add(v); rerender(); }
function toggleMore(d, k) { const id = d + k; state.expanded.has(id) ? state.expanded.delete(id) : state.expanded.add(id); rerender(); }
function rerender() {
  const focus = document.activeElement?.id, pos = document.activeElement?.selectionStart;
  const railScroll = $(".rail")?.scrollTop;
  const drawer = document.body.classList.contains("drawer-open");
  routing.keepScroll = true; route();
  if (drawer) document.body.classList.add("drawer-open");
  if (railScroll != null && $(".rail")) $(".rail").scrollTop = railScroll;
  if (focus && document.getElementById(focus)) { const el = document.getElementById(focus); el.focus(); if (pos != null && el.setSelectionRange) el.setSelectionRange(pos, pos); }
}
function setQ(d, v) { state[d].q = v; rerender(); }
function openDrawer(open) { document.body.classList.toggle("drawer-open", open); if (open) $(".rail")?.focus(); }

function listingShell(d, info, rail, head, body, active, cleared) {
  return `<div class="wrap">
    <div class="page-head">
      <div class="crumbs"><a href="#home">Datasets</a> ›</div>
      <div class="title-row" data-series="${d.series}"><h1><span class="mark"></span>${esc(d.title)}</h1>${helpToggle(d.id, info)}</div>
      <p class="subtitle">${esc(d.desc)}</p>
    </div>
    ${info ? infoDataset(d) : ""}
    <div class="listing">
      <div class="blanket" onclick="openDrawer(false)"></div>
      <aside class="rail" tabindex="-1" aria-label="Filters">
        <div style="display:flex"><button class="rail-close" type="button" onclick="openDrawer(false)" aria-label="Close filters">${ICON.close}</button></div>
        <div class="search-box">${ICON.search}<label class="sr" for="${d.id}-q">Search by name</label>
          <input id="${d.id}-q" type="search" placeholder="Name" value="${esc(state[d.id].q)}" oninput="setQ('${d.id}', this.value)"></div>
        ${rail}
        <div class="rail-foot"><span class="num">${head}</span>${active ? `<button type="button" onclick="${cleared}">Clear all</button>` : ""}</div>
      </aside>
      <section aria-label="Results">${body}</section>
    </div>
  </div>`;
}

function infoDataset(d) {
  const props = Object.entries(MODEL[d.id]);
  const types = { name: "text", country: "Country", city: "City", inception: "year", students: "integer", home: "IRI",
    university: "University", type: "Concept (Organizations)", topic: "Concept (EuroSciVoc)" };
  const card = { name: "1", country: "0..1", city: "0..1", inception: "0..1", students: "0..1", home: "0..*", university: "1", type: "0..1", topic: "0..*" };
  return `<aside class="info" aria-label="About this dataset">
    <div class="info-grid">
      <div>
        <h2>EC2U ${esc(d.title)}</h2>
        <p>${esc(d.desc)}</p>
        <dl>
          <dt>Records</dt><dd class="num">${fmt(d.count)}</dd>
          <dt>Publisher</dt><dd>EC2U Alliance</dd>
          <dt>Licence</dt><dd><a href="https://creativecommons.org/licenses/by-nc-nd/4.0/">CC BY-NC-ND 4.0</a></dd>
        </dl>
        <ul class="links">
          <li><a href="#${d.id}-info">Data model</a></li><li><a href="#${d.id}-info">API (OpenAPI)</a></li>
          <li><a href="#${d.id}-info">JSON Schema</a></li><li><a href="#${d.id}-info">TypeScript</a></li>
          ${d.id === "units" ? `<li><a href="#units-info">Organizations taxonomy</a></li><li><a href="#units-info">EuroSciVoc taxonomy</a></li>` : ""}
        </ul>
      </div>
      <div class="scroll">
        <h2>Properties</h2>
        <table><thead><tr><th>Property</th><th>Type</th><th>Card.</th><th>Description</th></tr></thead><tbody>
          ${props.map(([k, v]) => `<tr><td><code>${k}</code></td><td>${types[k]}</td><td class="num">${card[k]}</td><td>${esc(v)}</td></tr>`).join("")}
        </tbody></table>
        <p class="label" style="margin-top:var(--skin--spacing-050)">Generated from the data model.</p>
      </div>
    </div>
  </aside>`;
}

function chips(items) {
  return items.length ? `<ul class="chips" aria-label="Active filters">${items.map(([label, action]) =>
    `<li><button type="button" onclick="${action}" aria-label="Remove filter ${esc(label)}">${esc(label)} ${ICON.close}</button></li>`).join("")}</ul>` : "";
}

/* ---------- Universities listing ---------- */
function universities(info) {
  const d = ds("universities"), f = state.universities;
  const hits = UNIVERSITIES.filter(u => (!f.q || u.name.toLowerCase().includes(f.q.toLowerCase()))
    && (!f.country.size || f.country.has(u.country))
    && u.inception >= f.inception[0] && u.inception <= f.inception[1]
    && u.students >= f.students[0] && u.students <= f.students[1]);
  const countries = UNIVERSITIES.map(u => [u.country, u.country, 1]).sort((a, b) => a[0].localeCompare(b[0]));
  const maxS = Math.max(...UNIVERSITIES.map(u => u.students));
  const rangeChanged = f.inception[0] !== 1218 || f.inception[1] !== 1966 || f.students[0] !== 17345 || f.students[1] !== 40000;
  const active = f.q || f.country.size || rangeChanged;
  const rail = `
    <div class="facet">${hintFor("universities", "country", "Country")}${checklist("universities", "country", countries)}</div>
    <div class="facet">${hintFor("universities", "inception", "Founded")}
      <div class="range"><input type="number" aria-label="Founded from" value="${f.inception[0]}" onchange="setRange('inception',0,this.value)">
        <span class="label">to</span><input type="number" aria-label="Founded until" value="${f.inception[1]}" onchange="setRange('inception',1,this.value)"></div></div>
    <div class="facet">${hintFor("universities", "students", "Students")}
      <div class="range"><input type="number" aria-label="Students from" value="${f.students[0]}" step="1000" onchange="setRange('students',0,this.value)">
        <span class="label">to</span><input type="number" aria-label="Students up to" value="${f.students[1]}" step="1000" onchange="setRange('students',1,this.value)"></div></div>`;
  const chipList = [...[...f.country].map(c => [c, `toggleOpt('universities','country',${esc(JSON.stringify(c))})`]),
    ...(rangeChanged ? [["Founded or size range", "resetRanges()"]] : [])];
  const body = `
    <div class="results-head"><button class="rail-toggle" type="button" onclick="openDrawer(true)">${ICON.filter} Filters</button>
      <span class="total num">${hits.length === 9 ? "9 universities" : `${hits.length} of 9 universities`}</span>${chips(chipList)}</div>
    ${hits.length ? `<ul class="results">${hits.map(u => `
      <li class="uni-row"><a href="#university-${u.id}" tabindex="-1" aria-hidden="true"><img src="${IMG[u.id]}" alt=""></a>
        <div><a class="r-title" href="#university-${u.id}">${esc(u.name)}</a>
          <div class="r-meta"><span>${esc(u.city)}, ${esc(u.country)}</span></div>
          <p class="r-desc">${esc(u.desc)}</p>
          <dl class="stats"><dt>Founded</dt><dd class="num">${u.inception}</dd><span></span>
            <dt>Students</dt><dd class="num">${fmt(u.students)}</dd><span class="track" title="${fmt(u.students)} of ${fmt(maxS)} (largest)"><span style="width:${100 * u.students / maxS}%"></span></span></dl>
        </div></li>`).join("")}</ul>` : `<p class="empty">No universities match these filters. <button type="button" class="more" onclick="clearUniversities()">Clear all filters</button></p>`}`;
  return listingShell(d, info, rail, hits.length === 9 ? "9 items" : `${hits.length} matches`, body, active, "clearUniversities()");
}
function setRange(k, i, v) { const n = parseInt(v, 10); if (!isNaN(n)) state.universities[k][i] = n; rerender(); }
function resetRanges() { state.universities.inception = [1218, 1966]; state.universities.students = [17345, 40000]; rerender(); }
function clearUniversities() { const f = state.universities; f.q = ""; f.country.clear(); resetRanges(); }

/* ---------- Units listing ---------- */
function unitRow(u) {
  const un = uni(u.uni);
  return `<li><a class="r-title" href="#unit-${u.id}">${esc(u.name)}</a>
    <div class="r-meta"><span>${esc(un.name)}</span>${u.type ? `<span>${esc(u.type)}</span>` : ""}</div>
    ${u.desc ? `<p class="r-desc">${esc(u.desc)}</p>` : ""}
    <ul class="terms" aria-label="Topics">${u.topics.slice(0, 4).map(t => `<li><button type="button" onclick="filterTopic(${esc(JSON.stringify(t))})">${esc(t)}</button></li>`).join("")}</ul></li>`;
}
function filterTopic(t) { const f = state.units; f.topic.clear(); f.topic.add(t); go("units"); }

function units(info) {
  const d = ds("units"), f = state.units;
  const hits = UNITS.filter(u => (!f.q || u.name.toLowerCase().includes(f.q.toLowerCase()))
    && (!f.uni.size || f.uni.has(u.uni))
    && (!f.type.size || f.type.has(u.type))
    && (!f.topic.size || u.topics.some(t => f.topic.has(t))));
  const unis = UNIVERSITIES.map(u => [u.id, u.city, u.counts.units]).sort((a, b) => b[2] - a[2]);
  const types = UNIT_TYPES.map(([t, n]) => [t, t, n]);
  const topics = [...UNIT_TOPICS.map(([t, n]) => [t, t, n]), ...[...f.topic].filter(t => !UNIT_TOPICS.some(e => e[0] === t)).map(t => [t, t, 0])];
  const active = f.q || f.uni.size || f.type.size || f.topic.size;
  const rail = `
    <div class="facet">${hintFor("units", "university", "University")}${checklist("units", "uni", unis)}</div>
    <div class="facet">${hintFor("units", "type", "Type")}${checklist("units", "type", types, 8)}</div>
    <div class="facet">${hintFor("units", "topic", "Topic")}${checklist("units", "topic", topics, 8)}</div>`;
  const chipList = [
    ...(f.q ? [[`Name: ${f.q}`, "setQ('units','')"]] : []),
    ...[...f.uni].map(v => [uni(v).city, `toggleOpt('units','uni',${esc(JSON.stringify(v))})`]),
    ...[...f.type].map(v => [v, `toggleOpt('units','type',${esc(JSON.stringify(v))})`]),
    ...[...f.topic].map(v => [v, `toggleOpt('units','topic',${esc(JSON.stringify(v))})`])];
  const body = `
    <div class="results-head"><button class="rail-toggle" type="button" onclick="openDrawer(true)">${ICON.filter} Filters</button>
      <span class="total num">${active ? `${hits.length} of 40 sample units` : `${fmt(d.count)} units`}</span>${chips(chipList)}</div>
    <p class="note">Mockup: results come from a 40-record sample of the live data; facet counts cover the full dataset.</p>
    ${hits.length ? `<ul class="results">${hits.map(unitRow).join("")}</ul>`
      : `<p class="empty">No units in the sample match these filters. <button type="button" class="more" onclick="clearUnits()">Clear all filters</button></p>`}`;
  return listingShell(d, info, rail, active ? `${hits.length} matches` : `${fmt(d.count)} items`, body, active, "clearUnits()");
}
function clearUnits() { const f = state.units; f.q = ""; f.uni.clear(); f.type.clear(); f.topic.clear(); rerender(); }

/* ---------- Record pages ---------- */
function recordHead(d, title, sub, base, info) {
  return `<div class="page-head">
    <div class="crumbs"><a href="#${d.id}">${esc(d.label)}</a> ›</div>
    <div class="title-row" data-series="${d.series}"><h1><span class="mark"></span>${esc(title)}</h1>${helpToggle(base, info)}</div>
    ${sub ? `<p class="subtitle">${sub}</p>` : ""}
  </div>${info ? infoDataset(d) : ""}`;
}
function host(url) { try { return new URL(url).host.replace(/^www\./, ""); } catch { return url; } }

function universityPage(u, info) {
  const d = ds("universities");
  const rel = ["units", "programs", "courses", "events", "documents"].map(id => [ds(id), u.counts[id]]);
  const max = Math.max(...rel.map(r => r[1]), 1);
  const sample = UNITS.filter(x => x.uni === u.id);
  return `<div class="wrap">
    ${recordHead(d, u.name, `${esc(u.city)}, ${esc(u.country)}`, "university-" + u.id, info)}
    <div class="record">
      <div>
        <div class="props-group"><h2>Properties</h2>
          <dl class="props">
            <dt>Country</dt><dd>${esc(u.country)}</dd>
            <dt>City</dt><dd>${esc(u.city)}</dd>
            <dt>Founded</dt><dd class="num">${u.inception}</dd>
            <dt>Students</dt><dd class="num">${fmt(u.students)}</dd>
            <dt>Website</dt><dd><a href="${u.home}">${esc(host(u.home))}</a></dd>
          </dl></div>
      </div>
      <div>
        <img class="lead-img" src="${IMG[u.id]}" alt="${esc(u.name)}">
        <p class="prose">${esc(u.desc)}</p>
        <section class="related"><h2>Records from ${esc(u.city)}</h2>
          <div class="bars">${rel.map(([r, n]) => `
            <span class="lab" data-series="${r.series}"><span class="mark"></span>${r.live ? `<a href="#${r.id}" onclick="${r.id === "units" ? `state.units.uni.clear();state.units.uni.add('${u.id}')` : ""}">${esc(r.label)}</a>` : esc(r.label)}</span>
            <span class="n num">${fmt(n)}</span>
            <span class="track" data-series="${r.series}" title="${pct(n, r.count)}% of all ${r.label.toLowerCase()}"><span style="width:${100 * n / max}%"></span></span>`).join("")}
          </div></section>
        ${sample.length ? `<section class="related"><h2>Units</h2><ul class="results">${sample.slice(0, 6).map(unitRow).join("")}</ul>
          <a href="#units" onclick="state.units.uni.clear();state.units.uni.add('${u.id}')">All ${fmt(u.counts.units)} units at ${esc(u.city)}</a></section>` : ""}
      </div>
    </div></div>`;
}

function term(t) {
  const def = TOPIC_DEFS[t];
  return `<span class="term"><button type="button" class="more" style="padding:0" onclick="filterTopic(${esc(JSON.stringify(t))})" ${def ? `aria-describedby="def-${esc(t).replace(/\W/g, "")}"` : ""}>${esc(t)}</button>${def ?
    `<span class="def" role="tooltip" id="def-${esc(t).replace(/\W/g, "")}">${esc(def)}<em>EuroSciVoc taxonomy</em></span>` : ""}</span>`;
}

function unitPage(u, info) {
  const d = ds("units"), un = uni(u.uni);
  const siblings = UNITS.filter(x => x.uni === u.uni && x.id !== u.id).slice(0, 4);
  const shared = UNITS.filter(x => x.uni !== u.uni && x.topics.some(t => u.topics.includes(t))).slice(0, 4);
  return `<div class="wrap">
    ${recordHead(d, u.name, `<a href="#university-${un.id}">${esc(un.name)}</a>`, "unit-" + u.id, info)}
    <div class="record">
      <div>
        <div class="props-group"><h2>Properties</h2>
          <dl class="props">
            <dt>University</dt><dd><a href="#university-${un.id}">${esc(un.name)}</a></dd>
            ${u.type ? `<dt>Type</dt><dd><span class="term"><a href="#units" onclick="state.units.type.clear();state.units.type.add(${esc(JSON.stringify(u.type))})">${esc(u.type)}</a></span></dd>` : ""}
            <dt>Topics</dt><dd><ul class="terms" style="margin:0;font-size:inherit;display:grid;gap:.2em">${u.topics.map(t => `<li>${term(t)}</li>`).join("")}</ul></dd>
            ${u.home ? `<dt>Website</dt><dd><a href="${u.home}">${esc(host(u.home))}</a></dd>` : ""}
          </dl></div>
        <p class="ai">${ICON.spark}<span>AI-generated content: descriptions and topic classifications were produced with AI and may contain errors. <a href="#unit-${u.id}-info">How AI is used</a></span></p>
      </div>
      <div>
        ${u.desc ? `<p class="prose">${esc(u.desc)}</p>` : `<p class="prose label">No description is available for this unit.</p>`}
        ${siblings.length ? `<section class="related"><h2>Other units at ${esc(un.city)}</h2><ul class="results">${siblings.map(unitRow).join("")}</ul></section>` : ""}
        ${shared.length ? `<section class="related"><h2>Related units at other universities</h2><ul class="results">${shared.map(unitRow).join("")}</ul></section>` : ""}
      </div>
    </div></div>`;
}

window.addEventListener("hashchange", route);
window.addEventListener("keydown", e => { if (e.key === "Escape") openDrawer(false); });
document.addEventListener("click", e => {
  const a = e.target.closest("a[data-scope]");
  if (a) { e.preventDefault(); state.search = { scope: a.dataset.scope, q: "" }; go("search"); }
});
route();
