"""Assemble dist/ec2u-hub-mockup.html from src/ (skin, app styles, images, data, app logic)."""
import base64, json, pathlib
src = pathlib.Path(__file__).parent / "src"
imgs = {p.stem: "data:image/jpeg;base64," + base64.b64encode(p.read_bytes()).decode() for p in sorted((src / "img").glob("*.jpg"))}
html = (src / "shell.html").read_text()
html = html.replace("/*SKIN*/", (src / "skin.css").read_text()).replace("/*APP*/", (src / "app.css").read_text())
html = html.replace("/*IMG*/", "const IMG = " + json.dumps(imgs) + ";").replace("/*DATA*/", (src / "data.js").read_text())
html = html.replace("/*JS*/", (src / "app.js").read_text())
out = src.parent / "dist" / "ec2u-hub-mockup.html"
out.write_text(html)
print(f"wrote {out} ({len(html) // 1024} KB)")
