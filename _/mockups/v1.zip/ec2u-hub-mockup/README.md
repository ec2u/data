# EC2U Knowledge Hub Mockup

Mockup of the new Knowledge Hub: home, Universities and Units (listings and records).

- Published: https://claude.ai/artifact/2iZkPveUNS2RUaaPt9zeWu
- Requirements: `docs/ec2u-requirements.md` (published at https://claude.ai/artifact/2Jhex5mhr1yxarJF58Nad6)
- References: https://claude.ai/artifact/3HcnVDNtQbj8dy2898KK1G

## Build

```shell
python3 build.py   # writes dist/ec2u-hub-mockup.html
```

## Source

| File | Content |
| --- | --- |
| `src/skin.css` | metreeca/skin 0.2.0 bundled into one `skin` layer (`@property` rules hoisted) |
| `src/app.css` | `ec2u-skin.css` anchors, flagged skin overrides, app styles |
| `src/data.js` | Catalogue counts, universities, 40-unit sample, facet counts, topic definitions, model descriptions |
| `src/app.js` | Hash router and views (home, search, listings, records, info views) |
| `src/shell.html` | Page shell: top bar, footer, placeholders filled by `build.py` |
| `src/img/` | University photos from ec2u/data `src/main/static/blobs`, downscaled |

## Notes

- Counts come from the live EC2U graph (5 Nov 2026), not the dev server.
- Flagged skin overrides: Google Fonts faces, `--hub--color-brand`, `img { overflow: clip }` (reset lets `object-fit` images overflow).
- Filter state is in memory: published artifacts only pass a plain `#name` hash.
